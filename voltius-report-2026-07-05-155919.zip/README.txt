Voltius bug report
==================

Included:
  - App logs (what Voltius was doing, with sensitive values removed)
  - App version, operating system, and active plugins

NOT included:
  - Passwords, vault contents, or private keys
  - Terminal output or anything you typed

This report was saved on your computer. Nothing is sent automatically.
Send this file to the Voltius developer at contact@voltius.app or on GitHub.
